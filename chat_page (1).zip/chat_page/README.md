# Modern Chat Page with Pagination

A modern, minimalistic chat UI implementation using the FCRM Chat SDK v1.2.0 with pagination support.

## Features

- ✨ **Modern UI Design** - Clean, minimalistic interface
- 📱 **Responsive Layout** - Adapts to different screen sizes
- 🔄 **Infinite Scrolling** - Load older messages by scrolling to top
- 💬 **Real-time Messages** - Socket.IO integration
- 🎨 **Message Bubbles** - Beautiful user/agent message styling
- 📅 **Date Separators** - Automatic date grouping
- 🖼️ **Image Support** - Display image messages
- ⚡ **BLoC State Management** - Clean architecture with flutter_bloc
- 🔍 **Pagination** - Efficient message loading (20 messages per page)
- 🚫 **Duplicate Prevention** - Automatically prevents duplicate messages

## Structure

```
chat_page/
├── bloc/
│   ├── chat_bloc.dart        # Main BLoC logic with pagination
│   ├── chat_event.dart        # Events (Init, Send, Receive, LoadMore)
│   └── chat_state.dart        # States (Initial, Ready, Error)
├── widgets/
│   ├── message_bubble.dart    # Message bubble component
│   ├── chat_input.dart        # Input field component
│   └── loading_indicator.dart # Loading indicator
├── chat_page.dart             # Main page UI
└── README.md                  # This file
```

## Design

### Color Scheme
- **Background**: `#F5F5F5` (Light gray)
- **User Messages**: `#007AFF` (iOS Blue)
- **Agent Messages**: `#FFFFFF` (White)
- **App Bar**: `#FFFFFF` (White)
- **Input Background**: `#F5F5F5` (Light gray)

### Components

#### 1. App Bar
- Support agent avatar icon
- "Support Chat" title
- Online status indicator

#### 2. Message List
- Reverse scrolling (newest at bottom)
- Auto date separators
- Loading indicator at top
- Empty state message

#### 3. Message Bubbles
- Different colors for user/agent
- Rounded corners with tail
- Timestamp display
- Image support with loading states

#### 4. Chat Input
- Rounded input field
- Circular send button
- Auto-submit on enter

## Usage

### 1. Add to Your App

```dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'chat_page/bloc/chat_bloc.dart';
import 'chat_page/chat_page.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider(
        create: (context) => ChatBloc(),
        child: const ChatPage(),
      ),
    );
  }
}
```

### 2. Configure SDK

Update your credentials in `bloc/chat_bloc.dart`:

```dart
chat = FcrmChat(
  config: ChatConfig(
    baseUrl: 'YOUR_API_URL',
    companyToken: 'YOUR_COMPANY_TOKEN',
    appKey: 'YOUR_APP_KEY',
    appSecret: 'YOUR_APP_SECRET',
    socketUrl: 'YOUR_SOCKET_URL',
    enableLogging: true, // Set to false in production
  ),
);
```

### 3. Update User Data

In `_onInit` method, update the user registration:

```dart
await chat.register(
  userData: {
    'name': 'User Name',
    'phone': '+1234567890',
    'email': 'user@example.com', // Optional
  },
);
```

## How Pagination Works

### Initial Load
1. App starts → `ChatInit` event triggered
2. SDK initializes and registers user
3. Loads first 20 messages (page 1)
4. Displays in UI with pagination metadata

### Loading More
1. User scrolls to top (within 100px)
2. `ChatLoadMore` event triggered
3. Checks if not already loading and has more messages
4. Loads next page (page 2, 3, etc.)
5. Prepends older messages to list
6. Updates pagination state

### State Management
```dart
ChatReady(
  messages: [...],        // Current message list
  currentPage: 2,         // Current page number
  hasMore: true,          // More messages available?
  isLoadingMore: false,   // Currently loading?
)
```

## Features Explained

### Date Separators
Automatically groups messages by date:
- "Today" - For today's messages
- "Yesterday" - For yesterday's messages
- "DD/MM/YYYY" - For older dates

### Duplicate Prevention
Messages are checked by ID before adding:
```dart
final exists = messages.any((m) => m.id == message.id);
if (exists) return; // Skip duplicate
```

### Loading States
- **Initial**: Shows loading spinner
- **Empty**: Shows "No messages yet" state
- **Error**: Shows error with retry button
- **Loading More**: Shows indicator at top while loading

### Scroll Behavior
- Messages appear with newest at bottom
- `reverse: true` on ListView
- Auto-scroll after sending message
- Load trigger at top (100px threshold)

## Customization

### Change Colors

In `message_bubble.dart`:
```dart
color: isUser ? const Color(0xFF007AFF) : Colors.white,
```

### Change Page Size

In `chat_bloc.dart`:
```dart
final result = await chat.loadMessages(
  page: page,
  perPage: 50, // Change from 20 to 50
);
```

### Change Load Trigger

In `chat_page.dart`:
```dart
if (_scrollController.position.pixels <= 200) { // Changed from 100
  // Load more
}
```

### Customize Message Time Format

In `message_bubble.dart`:
```dart
String _formatTime(DateTime time) {
  // Add your custom formatting
  return '${time.hour}:${time.minute}';
}
```

## Performance Tips

1. **Adjust Page Size**: Balance between UX and performance
2. **Image Caching**: Images are cached by Flutter automatically
3. **Lazy Loading**: Only load when user scrolls
4. **Dispose Resources**: BLoC automatically disposes chat on close

## Troubleshooting

### Messages Not Loading
- Check SDK credentials in `chat_bloc.dart`
- Enable logging: `enableLogging: true`
- Check console for error messages

### Duplicate Messages
- Already handled in `_onReceive` method
- Socket listener cleanup in v1.2.0

### Pagination Not Working
- Ensure backend returns pagination metadata
- Check `hasMore` flag in state
- Verify scroll controller is attached

## Dependencies

```yaml
dependencies:
  flutter_bloc: ^8.1.3
  equatable: ^2.0.5
  fcrm_chat_sdk: ^1.2.0
```

## Version History

- **v1.0** - Initial implementation with pagination
- **v1.1** - Added duplicate prevention
- **v1.2** - Modern minimalistic redesign

## License

MIT License - Free to use and modify
