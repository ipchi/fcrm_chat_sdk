import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:fcrm_chat_sdk/fcrm_chat_sdk.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'chat_event.dart';
part 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final FcrmChat chat;
  StreamSubscription? _subscription;

  ChatBloc()
      : chat = FcrmChat(
          config: ChatConfig(
            baseUrl: 'https://fcrm.mudir.uz',
            companyToken: 'ELfHxZI1PsgUXeQWA1SCrH8gUJ0UoFwL',
            appKey: 'Cuv4lIKLrVhmhQgM6Wn49poS80Yp1ECf',
            appSecret: 'thxO0ZyH7wRZxRlxziBQWfAtGciDL7FO',
            socketUrl: 'https://socket-ipchi.mudir.uz',
            enableLogging: true,
          ),
        ),
        super(const ChatInitial()) {
    on<ChatInit>(_onInit);
    on<ChatSend>(_onSend);
    on<ChatMessageReceived>(_onReceive);
    on<ChatLoadMore>(_onLoadMore);

    add(const ChatInit());
  }

  // ------------------------- INIT -------------------------
  Future<void> _onInit(ChatInit event, Emitter<ChatState> emit) async {
    print('[ChatBloc] INIT started');

    try {
      print('[ChatBloc] Initializing chat...');
      await chat.initialize();
      print('[ChatBloc] Chat initialized OK');

      print('[ChatBloc] Registering user...');
      final isRegistered = await chat.isRegistered();
      print('[ChatBloc] isRegistered: $isRegistered');

      if (!isRegistered) {
        await chat.register(
          userData: {
            'name': 'Muhammadiy',
            'phone': '+998903433681',
          },
        );
        print('[ChatBloc] User registered OK');
      }

      print('[ChatBloc] Loading chat history...');
      final result = await chat.loadMessages(page: 1, perPage: 20);
      print('[ChatBloc] Loaded ${result.messages.length} of ${result.total} messages');
      print('[ChatBloc] Page ${result.currentPage}/${result.lastPage}, hasMore: ${result.hasMore}');

      emit(ChatReady(
        messages: result.messages,
        currentPage: result.currentPage,
        hasMore: result.hasMore,
      ));

      print('[ChatBloc] Subscribing to incoming messages...');
      _subscription = chat.onMessage.listen((message) {
        print('[ChatBloc] New message: ${message.content}');
        add(ChatMessageReceived(message: message));
      });

      print('[ChatBloc] INIT finished');
    } catch (e) {
      print('[ChatBloc] INIT ERROR: $e');
      emit(const ChatError());
    }
  }

  // ------------------------- SEND -------------------------
  Future<void> _onSend(ChatSend event, Emitter<ChatState> emit) async {
    print('[ChatBloc] Sending message: ${event.text}');
    try {
      await chat.sendMessage(event.text);
      print('[ChatBloc] Message sent OK');
    } catch (e) {
      print('[ChatBloc] SEND ERROR: $e');
    }
  }

  // ------------------------- RECEIVE -------------------------
  void _onReceive(ChatMessageReceived event, Emitter<ChatState> emit) {
    if (state is! ChatReady) return;

    final currentState = state as ChatReady;

    // Check if message already exists (prevent duplicates)
    final exists = currentState.messages.any((m) => m.id == event.message.id);
    if (exists) {
      print('[ChatBloc] Message ${event.message.id} already exists, skipping');
      return;
    }

    print('[ChatBloc] Adding new message: ${event.message.content}');
    final updated = List<ChatMessage>.from(currentState.messages)
      ..add(event.message);

    emit(currentState.copyWith(messages: updated));
  }

  // ------------------------- LOAD MORE -------------------------
  Future<void> _onLoadMore(ChatLoadMore event, Emitter<ChatState> emit) async {
    if (state is! ChatReady) return;

    final currentState = state as ChatReady;

    // Don't load if already loading or no more messages
    if (currentState.isLoadingMore || !currentState.hasMore) {
      print('[ChatBloc] Skip loading: isLoadingMore=${currentState.isLoadingMore}, hasMore=${currentState.hasMore}');
      return;
    }

    print('[ChatBloc] Loading more messages (page ${currentState.currentPage + 1})');

    // Show loading indicator
    emit(currentState.copyWith(isLoadingMore: true));

    try {
      final result = await chat.loadMessages(
        page: currentState.currentPage + 1,
        perPage: 20,
      );

      print('[ChatBloc] Loaded ${result.messages.length} more messages');
      print('[ChatBloc] Page ${result.currentPage}/${result.lastPage}, hasMore: ${result.hasMore}');

      // Insert older messages at the beginning
      final updated = List<ChatMessage>.from(result.messages)
        ..addAll(currentState.messages);

      emit(ChatReady(
        messages: updated,
        isLoadingMore: false,
        currentPage: result.currentPage,
        hasMore: result.hasMore,
      ));
    } catch (e) {
      print('[ChatBloc] LOAD MORE ERROR: $e');
      emit(currentState.copyWith(isLoadingMore: false));
    }
  }

  @override
  Future<void> close() {
    _subscription?.cancel();
    chat.dispose();
    return super.close();
  }
}
