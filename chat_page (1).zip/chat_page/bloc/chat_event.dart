part of 'chat_bloc.dart';

sealed class ChatEvent extends Equatable {
  const ChatEvent();

  @override
  List<Object?> get props => const [];
}

final class ChatInit extends ChatEvent {
  const ChatInit();
}

final class ChatSend extends ChatEvent {
  const ChatSend({required this.text});

  final String text;

  @override
  List<Object?> get props => [text];
}

final class ChatMessageReceived extends ChatEvent {
  const ChatMessageReceived({required this.message});

  final ChatMessage message;

  @override
  List<Object?> get props => [message];
}

final class ChatLoadMore extends ChatEvent {
  const ChatLoadMore();
}
