part of 'chat_bloc.dart';

sealed class ChatState extends Equatable {
  const ChatState({
    required this.messages,
    this.loading = false,
    this.isLoadingMore = false,
    this.currentPage = 1,
    this.hasMore = false,
  });

  final List<ChatMessage> messages;
  final bool loading;
  final bool isLoadingMore;
  final int currentPage;
  final bool hasMore;

  @override
  List<Object?> get props => [messages, loading, isLoadingMore, currentPage, hasMore];
}

final class ChatInitial extends ChatState {
  const ChatInitial() : super(messages: const [], loading: true);
}

final class ChatReady extends ChatState {
  const ChatReady({
    required super.messages,
    super.isLoadingMore = false,
    super.currentPage = 1,
    super.hasMore = false,
  });

  ChatReady copyWith({
    List<ChatMessage>? messages,
    bool? isLoadingMore,
    int? currentPage,
    bool? hasMore,
  }) {
    return ChatReady(
      messages: messages ?? this.messages,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      currentPage: currentPage ?? this.currentPage,
      hasMore: hasMore ?? this.hasMore,
    );
  }
}

final class ChatError extends ChatState {
  const ChatError({super.messages = const []});
}
